(function () {
  function atualizarSaudacao() {
    const usuario = window.currentUser;
    const saudacao = document.getElementById('homeSaudacao');
    if (!usuario || !saudacao) return;

    const nome = usuario.name || (usuario.email ? usuario.email.split('@')[0] : 'por aqui');
    saudacao.textContent = `Olá, ${nome}!`;
  }

  function mostrarProgresso(percentual) {
    const valor = document.getElementById('statProgresso');
    const texto = document.getElementById('textoProgresso');
    const barra = document.getElementById('barraProgresso');
    const preenchida = document.getElementById('barraProgressoPreenchida');
    if (valor) valor.textContent = `${percentual}%`;
    if (texto) texto.textContent = `${percentual}%`;
    if (barra) barra.setAttribute('aria-valuenow', String(percentual));
    if (preenchida) preenchida.style.width = `${percentual}%`;
  }

  async function atualizarEstatisticas() {
    if (!window.Progresso) return;
    const dados = await window.Progresso.carregar();
    const statSinais = document.getElementById('statSinais');
    const statFavoritos = document.getElementById('statFavoritos');
    const statQuizzes = document.getElementById('statQuizzes');
    if (statSinais) statSinais.textContent = dados.sinais_vistos.length;
    if (statFavoritos) statFavoritos.textContent = dados.termos_favoritos.length;
    if (statQuizzes) statQuizzes.textContent = dados.quizzes_concluidos.length;
    const percentual = window.Progresso.percentualGeral();
    mostrarProgresso(percentual === null ? 0 : percentual);
  }

  window.addEventListener('auth-changed', () => {
    atualizarSaudacao();
    atualizarEstatisticas();
  });
  window.addEventListener('progresso-carregado', atualizarEstatisticas);

  document.addEventListener('DOMContentLoaded', () => {
    atualizarSaudacao();
    atualizarEstatisticas();
  });
})();
